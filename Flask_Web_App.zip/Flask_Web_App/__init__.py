# Package initializer for deployment.
# Expose the Flask application instance as 'app' when importing Flask_Web_App.
from .app import app  # noqa: F401
